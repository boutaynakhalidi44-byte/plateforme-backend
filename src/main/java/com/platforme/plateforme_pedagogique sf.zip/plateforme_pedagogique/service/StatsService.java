package com.platforme.plateforme_pedagogique.service;

import com.platforme.plateforme_pedagogique.dto.StatsEnseignantDTO;
import com.platforme.plateforme_pedagogique.dto.StatsEtudiantDTO;
import com.platforme.plateforme_pedagogique.entity.*;
import com.platforme.plateforme_pedagogique.entity.Module;
import com.platforme.plateforme_pedagogique.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class StatsService {

    @Autowired
    private InscriptionRepository inscriptionRepository;

    @Autowired
    private ModuleRepository moduleRepository;

    @Autowired
    private ChapitreRepository chapitreRepository;


    // ===== Stats Enseignant =====
    public StatsEnseignantDTO getStatsEnseignant(Long enseignantId) {

        StatsEnseignantDTO stats = new StatsEnseignantDTO();

        List<Module> modules = moduleRepository.findByEnseignantId(enseignantId);
        stats.setTotalModules((long) modules.size());

        Set<Long> etudiantIds = new HashSet<>();
        long totalEnAttente = 0;

        for (Module module : modules) {
            List<Inscription> inscriptions = inscriptionRepository.findByModuleId(module.getId());
            for (Inscription i : inscriptions) {
                if (i.getStatut() == Inscription.Statut.ACCEPTE) {
                    if (i.getEtudiant() != null) {
                        etudiantIds.add(i.getEtudiant().getId());
                    }
                }
                if (i.getStatut() == Inscription.Statut.EN_ATTENTE) {
                    totalEnAttente++;
                }
            }
        }

        stats.setTotalEtudiants((long) etudiantIds.size());
        stats.setInscriptionsEnAttente(totalEnAttente);

        List<StatsEnseignantDTO.ModuleStatsDTO> statsModules = new ArrayList<>();

        for (Module module : modules) {
            StatsEnseignantDTO.ModuleStatsDTO ms = new StatsEnseignantDTO.ModuleStatsDTO();
            ms.setModuleId(module.getId());
            ms.setModuleTitre(module.getTitre());

            long nbInscrits = inscriptionRepository.findByModuleId(module.getId())
                    .stream()
                    .filter(i -> i.getStatut() == Inscription.Statut.ACCEPTE)
                    .count();
            ms.setNbInscrits(nbInscrits);

            long nbChapitres = chapitreRepository
                    .findByModuleIdOrderByOrdre(module.getId())
                    .size();
            ms.setNbChapitres(nbChapitres);

            List<Chapitre> chapitres = chapitreRepository.findByModuleIdOrderByOrdre(module.getId());

            statsModules.add(ms);
        }

        stats.setStatsParModule(statsModules);
        return stats;
    }

    // ===== Stats Etudiant =====
    public StatsEtudiantDTO getStatsEtudiant(Long etudiantId) {

        StatsEtudiantDTO stats = new StatsEtudiantDTO();

        List<Inscription> inscriptions = inscriptionRepository
                .findByEtudiantId(etudiantId)
                .stream()
                .filter(i -> i.getStatut() == Inscription.Statut.ACCEPTE)
                .collect(Collectors.toList());

        stats.setTotalModules((long) inscriptions.size());


        List<StatsEtudiantDTO.ModuleProgressionDTO> statsModules = new ArrayList<>();

        for (Inscription inscription : inscriptions) {
            Module module = inscription.getModule();
            if (module == null) continue;

            StatsEtudiantDTO.ModuleProgressionDTO mp = new StatsEtudiantDTO.ModuleProgressionDTO();
            mp.setModuleId(module.getId());
            mp.setModuleTitre(module.getTitre());

            long totalChapitres = chapitreRepository
                    .findByModuleIdOrderByOrdre(module.getId())
                    .size();
            mp.setTotalChapitres(totalChapitres);

            statsModules.add(mp);
        }

        stats.setStatsParModule(statsModules);
        return stats;
    }
}