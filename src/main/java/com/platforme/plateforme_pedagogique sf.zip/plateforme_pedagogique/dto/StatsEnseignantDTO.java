package com.platforme.plateforme_pedagogique.dto;


import lombok.Data;
import java.util.List;

@Data
public class StatsEnseignantDTO {
    private Long totalModules;
    private Long totalEtudiants;
    private Long inscriptionsEnAttente;
    private List<ModuleStatsDTO> statsParModule;

    @Data
    public static class ModuleStatsDTO {
        private Long moduleId;
        private String moduleTitre;
        private Long nbInscrits;
        private Long nbChapitres;
        private Double moyenneScore;
    }
}